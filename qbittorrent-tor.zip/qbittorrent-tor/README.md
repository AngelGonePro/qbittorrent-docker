# qBittorrent + Tor

Routes all peer/tracker traffic through Tor via SOCKS5. Legitimate-use
setup (Linux ISOs, indie creator torrent releases, content you have
rights to seed) — not configured for anything beyond that.

## Before first deploy

The pre-seeded `config/qBittorrent/qBittorrent.conf` in this folder
already has the Tor proxy and safety settings baked in. Don't run
`docker compose up` before checking this file is actually in place at
`./config/qBittorrent/qBittorrent.conf` — if it's missing, the image
generates its own default config on first boot without any of this,
and you'd be torrenting with your real IP exposed until you noticed.

## Shared storage

Downloads land in `/root/data/Downloads` — a dedicated subfolder
inside the same shared tree Nextcloud and Jellyfin already use,
**not** dumped directly into `Movies`/`TV`/`Music`. This is
deliberate: torrent downloads include partial/incomplete files and
non-media junk while downloading, and you don't want that showing up
in Jellyfin's libraries mid-download. Create the folder with the same
ownership as the rest of the shared tree before first deploy:

```bash
mkdir -p /root/data/Downloads
chown 82:65600 /root/data/Downloads
chmod 2775 /root/data/Downloads
```

Move finished files into `Movies`/`TV`/`Shows` manually once you've
reviewed them — this keeps your organized libraries clean.

## Deploy

```bash
cp .env.example .env
nano .env   # set WEBUI_PORT if 8090 conflicts with anything
docker compose up -d
```

## First-time WebUI login

The linuxserver image generates a random temporary password on first
boot. Get it from the logs, not a default you'd guess:

```bash
docker compose logs qbittorrent | grep -i "temporary password"
```

Log in once with that, then immediately change it under
**Tools → Options → Web UI → Authentication**.

## Verify Tor is actually working — don't just trust the config

**1. Confirm Tor itself bootstrapped successfully:**
```bash
docker compose logs tor | grep -i bootstrapped
```
Should show `Bootstrapped 100% (done)`. If it doesn't get there,
qBittorrent will still start but every connection attempt will just
fail — not leak, but not work either.

**2. Confirm qBittorrent's own proxy settings actually took effect**
(the pre-seeded config can get silently overwritten on first boot
in some image versions — verify, don't assume):
```
WebUI → Tools → Options → Connection → Proxy Server
```
Should show: Type `SOCKS5`, Host `tor`, Port `9050`, both "Use proxy
for peer connections" and "Use proxy for torrents" checked.

**3. Confirm DHT/PeX/LSD are actually off** (same screen area, under
Connection → Peer Connection Protocol) — all three boxes unchecked.
This is the one that matters most: if any of these got re-enabled
somehow, your real IP leaks to peers regardless of what the proxy
settings say, since UDP never touches the SOCKS5 proxy at all.

## Known limitation, not a bug

Tor only proxies outbound connections. You won't be able to accept
incoming peer connections through it, which means fewer usable peers
and generally slower speeds than a normal non-Tor torrent client.
This is inherent to how Tor works, not something fixable in config.
